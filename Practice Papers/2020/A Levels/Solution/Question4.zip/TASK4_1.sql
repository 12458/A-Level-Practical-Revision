CREATE TABLE People(
    PersonID INTEGER PRIMARY KEY AUTOINCREMENT,
    FullName TEXT,
    DateOfBirth TEXT,
    ScreenName TEXT,
    IsAdult INTEGER
)