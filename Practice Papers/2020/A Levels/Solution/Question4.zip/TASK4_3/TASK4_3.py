from flask import Flask
from flask import render_template 
import sqlite3

app = Flask(__name__)

@app.route("/")
def root():
    with open("people.txt", "r") as csv_file:
        import csv
        csv_reader = csv.reader(csv_file, delimiter=',')
        data = list(csv_reader)
    return render_template("index.html", data=data)

app.run()