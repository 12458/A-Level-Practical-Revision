import sqlite3
import csv


class Person:
    def __init__(self, full_name, date_of_birth):
        self.full_name = full_name
        self.date_of_birth = date_of_birth

    def is_adult(self):
        import datetime
        return (datetime.datetime.now().year - int(self.date_of_birth[:4])) > 180

    def screen_name(self):
        name = self.full_name.strip()
        import re
        regex = '[.!?\\-\\;\\, ]'
        r = re.compile(regex)
        name = re.sub(r, '', name)
        name = name + self.date_of_birth[5:7] + self.date_of_birth[8:]
        return name


class Staff(Person):
    def is_adult(self):
        return True

    def screen_name(self):
        name = self.full_name.strip()
        import re
        regex = '[.!?\\-\\;\\, ]'
        r = re.compile(regex)
        name = re.sub(r, '', name)
        name = name + self.date_of_birth[5:7] + self.date_of_birth[8:] + 'Staff'
        return name


class Student(Person):
    def is_adult(self):
        return False


p = Person('John Tan', '2000-06-01')
print(p.screen_name())

students = []
staff = []
people = []

with open('people.txt', 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    data = list(csv_reader)
    for row in data:
        if row[2] == 'Person':
            people.append(Person(row[0], row[1]))
        elif row[2] == 'Student':
            students.append(Student(row[0], row[1]))
        else:
            staff.append(Staff(row[0], row[1]))


def open_DB():
    '''
    Opens and returns a DB connection
    '''
    connection = sqlite3.connect('schools.db')
    connection.row_factory = sqlite3.Row
    return connection


con = open_DB()
cur = con.cursor()

school_people = students + staff + people
for someone in school_people:
    sql_statement = \
        '''
    INSERT INTO People(FullName, DateOfBirth, ScreenName, IsAdult)
    VALUES (?,?,?,?)
    '''
    cur.execute(sql_statement, (someone.full_name, someone.date_of_birth, someone.screen_name(), int(someone.is_adult())))
    con.commit()

con.close()
